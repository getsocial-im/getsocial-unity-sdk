﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_RatePopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;   
		public FsmString yes; 	
		public FsmString no;	
		public FsmString later; 
		public FsmString androidAppUrl; 
		public FsmString appleId; 

		public FsmEvent yesEvent;
		public FsmEvent noEvent;
		public FsmEvent laterEvent;
		
		public override void OnEnter() {
			
			MNRateUsPopup rateUs = new MNRateUsPopup (title.Value, message.Value, yes.Value, no.Value, later.Value);

				rateUs.SetAppleId (appleId.Value);
				rateUs.SetAndroidAppUrl (androidAppUrl.Value);
				rateUs.AddDeclineListener (() => {
						Debug.Log("Rate us declined");

						Finish();
				});

				rateUs.AddRemindListener (() => {
						Debug.Log("Remind me later");
						Fsm.Event(laterEvent);

						Finish();
				});

				rateUs.AddRateUsListener (() => {
						Debug.Log("Thank you, for rating us!");
						Fsm.Event(yesEvent);

						Finish();
				});

				rateUs.AddDismissListener (() => {
						Debug.Log("Rate us dialog dismissed :(");
						Fsm.Event(noEvent);

						Finish();
				});

				rateUs.Show ();			
		}

		public override void Reset() {
				base.Reset();

				title 						= "Rate title";
				message   			= "Rate message";
				yes 							= "Okay";
				no 							= "No";
				later  						= "Later";
				androidAppUrl 	= "market://details?id=com.google.earth";
				appleId 					= "itms-apps://itunes.apple.com/id375380948?mt=8";			
		}
	}
}


