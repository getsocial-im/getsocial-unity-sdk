﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_DialogPopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message; 

		public FsmEvent yesEvent;
		public FsmEvent noEvent;
		
		public override void OnEnter() {
			
				MNPopup popup = new MNPopup (title.Value, message.Value);

				popup.AddAction ("Action1", () => {
					  Debug.Log("Action 1 callback");
					  Fsm.Event(yesEvent);

					  Finish();
				});	

				popup.AddAction ("Action2", () => {
					  Debug.Log("Action 2 callback");
					  Fsm.Event(noEvent);

					  Finish();
				});	

				popup.Show ();
		}
		
		public override void Reset() {
				base.Reset();
			
				title 			= "Dialog Title";
				message   = "Dialog Message";			
		}		
	}
}


