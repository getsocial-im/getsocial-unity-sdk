﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_MessagePopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;
		
		public override void OnEnter() {
			
				MNPopup popup = new MNPopup (title.Value, message.Value);

				popup.AddAction ("Ok", () => {
					Debug.Log("Ok action callback");

					Finish();
				});

				popup.AddDismissListener (() => {
					Debug.Log("Dismiss listener");

					Finish();
				});	

				popup.Show ();
		}

		public override void Reset() {
				base.Reset();
			
				title 			= "Message title";
				message   = "Message text";
		}
	}
}


