//
//  GetSocial
//
//  Copyright © 2017 GetSocial BV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GetSocial/GetSocialExecutionPolicy.h>

@interface GetSocialSilentExecutionPolicyDelegate : NSObject<GetSocialExecutionPolicyDelegate>

@end
